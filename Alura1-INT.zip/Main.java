class Main {
  public static void main(String[] args) 
  {
    int idade = 23;
    System.out.println("Minha idade é: " + idade);
  }
}
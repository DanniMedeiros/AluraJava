class Main {
  public static void main(String[] args) 
  {
    double salario = 523.44; 
    System.out.println("Meu salário é: "+ salario);
  }
}
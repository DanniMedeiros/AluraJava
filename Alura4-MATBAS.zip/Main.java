class Main {
  public static void main(String[] args) 
  {
    double conta1 = 54.76+87.42;
    int conta2 = 16/8;
    int conta3 = 778 * 253;
    System.out.println("O resultado da primeira conta é: "+conta1+"\n O segundo resultado da conta é: "+conta2+"\n O terceiro resultado da conta é: "+conta3);
  }
}
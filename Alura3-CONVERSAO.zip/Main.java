class Main {
  public static void main(String[] args) 
  {
    double Salario = 1270.50;
    int valor = (int) Salario; //fazendo conversão de uma variavel com numero decimal para inteiro
    System.out.println(valor);
  }
}